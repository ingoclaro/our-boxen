require 'spec_helper'

describe 'ruby::with_brew_libs::version' do
  let(:title) { 'ruby::with_brew_libraries::version' }
  let(:params) { {:version => '1.9.3-p392-perf'} }
  let(:facts) {
    {
      :boxen_home           => '/opt/boxen',
      :brew_prefix_readline => 'readline_prefix',
      :brew_prefix_openssl  => 'openssl_prefix'
    }
  }

  it do
    should contain_class('ruby::with_brew_libs::dependencies')
  end

  it 'installs the specified ruby with the brew libraries' do
    ruby_conf_opts = [
      "--with-readline-dir=readline_prefix",
      "--with-openssl-dir=openssl_prefix"
    ].join(" ")

    should contain_ruby__version('1.9.3-p392-perf').
             with_ruby_conf_opts(ruby_conf_opts)
  end
end
