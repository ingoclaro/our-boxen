require 'spec_helper'

describe 'ruby::version' do
  let(:facts) do
    {
      :boxen_home                  => '/opt/boxen',
      :luser                       => 'wfarr',
      :macosx_productversion_major => '10.8'
    }
  end

  let(:title) { '1.9.3-p194' }

  context "ensure => present" do
    context "default params" do
      it do
        should include_class('ruby')

        should contain_exec('ruby-install-1.9.3-p194').with({
          :command  => "/opt/boxen/rbenv/bin/rbenv install 1.9.3-p194",
          :cwd      => '/opt/boxen/rbenv/versions',
          :provider => 'shell',
          :timeout  => 0,
          :creates  => '/opt/boxen/rbenv/versions/1.9.3-p194'
        })

        should contain_ruby__gem('bundler for 1.9.3-p194').with({
          :gem     => 'bundler',
          :ruby    => '1.9.3-p194',
          :version => '~> 1.3'
        })

        should contain_ruby__gem('rbenv-autohash for 1.9.3-p194').with({
          :gem     => 'rbenv-autohash',
          :ruby    => '1.9.3-p194'
        })
      end
    end

    context "when conf_opts, ruby_conf_opts, and cflags are nil" do
      it do
        should contain_exec('ruby-install-1.9.3-p194').with_environment([
          "CC=/usr/bin/cc",
          "RBENV_ROOT=/opt/boxen/rbenv",
          "CFLAGS=-Wno-error=shorten-64-to-32"
        ])
      end
    end

    { :conf_opts      => "CONFIGURE_OPTS",
      :ruby_conf_opts => "RUBY_CONFIGURE_OPTS" }.each do |option,env_var_name|
      context "when #{option} is not nil" do
        let(:params) do
          { option => "flocka" }
        end

        it do
          should contain_exec('ruby-install-1.9.3-p194').with_environment([
            "CC=/usr/bin/cc",
            "RBENV_ROOT=/opt/boxen/rbenv",
            "#{env_var_name}=flocka",
            "CFLAGS=-Wno-error=shorten-64-to-32"
          ])
        end
      end
    end
  end

  context "when cflags is not nil" do
    let(:params) do
      { :cflags => "flocka" }
    end

    it do
      should contain_exec('ruby-install-1.9.3-p194').with_environment([
        "CC=/usr/bin/cc",
        "RBENV_ROOT=/opt/boxen/rbenv",
        "CFLAGS=flocka"
      ])
    end
  end

  context "ensure => absent" do
    let(:params) do
      {
        :ensure => 'absent'
      }
    end

    it do
      should contain_file('/opt/boxen/rbenv/versions/1.9.3-p194').with({
        :ensure => 'absent',
        :force  => true
      })
    end
  end
end
