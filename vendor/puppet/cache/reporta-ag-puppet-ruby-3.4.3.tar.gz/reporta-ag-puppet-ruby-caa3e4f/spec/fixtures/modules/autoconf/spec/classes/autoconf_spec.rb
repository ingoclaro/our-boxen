require 'spec_helper'

describe 'autoconf' do
  it { should contain_package('autoconf') }
end
