require 'spec_helper'

describe 'ruby::with_brew_libs::2_0_0_p0' do
  let(:title) { 'ruby::with_brew_libs::2_0_0_p0' }
  let(:facts) { {:boxen_home => '/opt/boxen'} }

  it do
    should contain_ruby__with_brew_libs__version('2.0.0-p0')
  end
end
