require 'spec_helper'

describe 'ruby::with_brew_libs::1_9_3_p392_perf' do
  let(:facts) { {:boxen_home => '/opt/boxen'} }

  it do
    should contain_ruby__definition('1.9.3-p392-perf')
  end

  it do
    should contain_ruby__with_brew_libs__version('1.9.3-p392-perf')
  end
end
