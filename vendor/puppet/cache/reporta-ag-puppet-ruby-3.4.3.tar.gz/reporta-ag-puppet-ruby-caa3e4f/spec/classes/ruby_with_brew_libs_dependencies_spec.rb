require 'spec_helper'

describe 'ruby::with_brew_libs::dependencies' do
  let(:facts) { {:boxen_home => '/opt/boxen'} }

  it do
    should include_class('autoconf')
  end

  it 'installs the dependent homebrew packages' do
    should contain_package('openssl')
    should contain_package('readline')
  end
end
