%w(readline openssl).each do |prefix|
  Facter.add("brew_prefix_#{prefix}") do
    confine :operatingsystem => :darwin

    setcode do
      Facter::Util::Resolution.exec("brew --prefix #{prefix}")
    end
  end
end
